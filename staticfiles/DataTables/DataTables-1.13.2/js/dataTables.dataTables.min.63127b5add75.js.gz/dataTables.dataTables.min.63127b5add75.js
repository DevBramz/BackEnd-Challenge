/*! DataTables styling integration
 * ©2018 SpryMedia Ltd - datatables.net/license
 */
!function(t){"function"==typeof define&&define.amd?define(["jquery","datatables.net"],function(e){return t(e,window,document)}):"object"==typeof exports?module.exports=function(e,n){return e=e||window,(n=n||("undefined"!=typeof window?require("jquery"):require("jquery")(e))).fn.dataTable||require("datatables.net")(e,n),t(n,0,e.document)}:t(jQuery,window,document)}(function(e,n,t,u){"use strict";return e.fn.dataTable});